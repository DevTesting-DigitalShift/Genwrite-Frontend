<?php
if (!defined('ABSPATH'))
    exit;

add_action('aiblogger_cron_event', 'aiblogger_process_sideload_posts');

function aiblogger_process_sideload_posts()
{
    $posts = get_posts([
        'post_type' => 'post',
        'meta_key' => '_aiblogger_needs_sideload',
        'meta_value' => true,
        'posts_per_page' => 5,
    ]);

    foreach ($posts as $post) {
        $post_id = $post->ID;
        $content = $post->post_content;

        $image_urls = aiblogger_extract_image_urls($content);
        $new_content = $content;
        $errors = 0;

        foreach ($image_urls as $img_url) {
            $media_id = aiblogger_sideload_image($img_url, $post_id);

            if (!is_wp_error($media_id)) {
                $uploaded_url = wp_get_attachment_url($media_id);
                $new_content = str_replace($img_url, $uploaded_url, $new_content);
            } else {
                $errors++;
            }
        }

        if ($errors === 0) {
            // All images processed
            wp_update_post([
                'ID' => $post_id,
                'post_content' => $new_content,
            ]);
            update_post_meta($post_id, '_aiblogger_needs_sideload', false);
            delete_post_meta($post_id, '_aiblogger_sideload_attempts');
        } else {
            // Retry logic
            $attempts = (int) get_post_meta($post_id, '_aiblogger_sideload_attempts', true);
            $attempts++;
            update_post_meta($post_id, '_aiblogger_sideload_attempts', $attempts);

            if ($attempts >= 3) {
                delete_post_meta($post_id, '_aiblogger_needs_sideload');
                error_log("AIBlogger: Max sideload attempts reached for post ID $post_id");
            }
        }
    }
}

// Every 10 minutes
add_filter('cron_schedules', function ($schedules) {
    $schedules['every_10_minutes'] = [
        'interval' => 600,
        'display' => __('Every 10 Minutes'),
    ];
    return $schedules;
});

// Register custom cron interval
add_filter('cron_schedules', function($schedules) {
    $schedules['every_10_minutes'] = [
        'interval' => 600,
        'display'  => __('Every 10 Minutes')
    ];
    return $schedules;
});

// Activation hook to schedule cron
register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('aiblogger_cron_event')) {
        wp_schedule_event(time(), 'every_10_minutes', 'aiblogger_cron_event');
		update_option('aiblogger_cron_scheduled', true);
        error_log('✅ aiblogger_cron_event scheduled on activation');
}
});

// Deactivation hook to clear it
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('aiblogger_cron_event');
});

