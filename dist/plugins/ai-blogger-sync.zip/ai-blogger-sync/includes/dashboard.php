<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

add_action('admin_menu', function () {
    add_menu_page(
        'AI Blogger Sync',
        'AI Blogger',
        'manage_options',
        'ai-blogger-sync',
        'aiblogger_admin_dashboard',
		'dashicons-cloud',
        26
    );
});

// Enqueue admin assets only on this plugin page
add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ($hook === 'toplevel_page_ai-blogger-sync') {
        wp_enqueue_style(
            'ai-blogger-sync-admin',
            plugin_dir_url(__FILE__) . 'assets/style.css',
            array(),
            '1.0.0'
        );
    }
} );

function aiblogger_admin_dashboard() {
    // Get categories & tags
    $all_categories = get_categories(['hide_empty' => false]);
    $all_tags = get_tags(['hide_empty' => false]);

    // Current filters
    $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
    $category_filter = isset($_GET['cat']) ? intval($_GET['cat']) : 0;
    $tag_filter = isset($_GET['tag']) ? intval($_GET['tag']) : 0;

    // Sorting & pagination
    $orderby = isset($_GET['orderby']) ? sanitize_text_field(wp_unslash($_GET['orderby'])) : 'date';
    $order = isset($_GET['order']) && in_array(strtoupper(sanitize_text_field(wp_unslash($_GET['order']))), ['ASC', 'DESC']) ? strtoupper(sanitize_text_field(wp_unslash($_GET['order']))) : 'DESC';
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;

    // Query args
    $args = [
        'post_type' => 'post',
        'posts_per_page' => $per_page,
        'offset' => $offset,
        'orderby' => $orderby,
        'order' => $order,
        's' => $search,
        'meta_query' => [
            [
                'key' => 'meta_title',
                'compare' => 'EXISTS'
            ]
        ],
        'cat' => $category_filter,
        'tag_id' => $tag_filter
    ];

    $query = new WP_Query($args);
    $total_posts = $query->found_posts;
    $total_pages = ceil($total_posts / $per_page);
    ?>
    <div class="wrap ai-blogger-dashboard">
        <h1>
            <img src="<?php echo esc_url( plugin_dir_url(__FILE__) . 'assets/logo.png'); ?>" alt="Logo" style="height:32px;vertical-align:middle;margin-right:10px;">
            AI Blogger Sync Connected
        </h1>
        <p>Plugin is connected with <a href="https://app.genwrite.co" target="_blank">app.genwrite.co</a>.</p>

        <form method="get" style="margin: 1rem 0;">
            <input type="hidden" name="page" value="ai-blogger-sync" />
            <input type="text" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search blog posts..." />

            <select name="cat">
                <option value="0">All Categories</option>
                <?php foreach ($all_categories as $cat): ?>
                    <option value="<?php echo esc_html($cat->term_id); ?>" <?php selected($category_filter, $cat->term_id); ?>><?php echo esc_html($cat->name); ?></option>
                <?php endforeach; ?>
            </select>

            <select name="tag">
                <option value="0">All Tags</option>
                <?php foreach ($all_tags as $tag): ?>
                    <option value="<?php echo esc_html($tag->term_id); ?>" <?php selected($tag_filter, $tag->term_id); ?>><?php echo esc_html($tag->name); ?></option>
                <?php endforeach; ?>
            </select>

            <input type="submit" class="button" value="Filter" />
        </form>

        <h2>Synced Blog Posts</h2>
        <p>Total Synced Posts: <strong><?php echo esc_html($total_posts); ?></strong></p>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><a href="<?php echo esc_url(add_query_arg(['orderby' => 'title', 'order' => ($orderby == 'title' && $order == 'ASC') ? 'DESC' : 'ASC'])); ?>">Title</a></th>
                    <th>Keywords</th>
                    <th>Meta Desc</th>
                    <th>Views</th>
                    <th><a href="<?php echo esc_url(add_query_arg(['orderby' => 'date', 'order' => ($orderby == 'date' && $order == 'ASC') ? 'DESC' : 'ASC'])); ?>">Date</a></th>
                    <th>Categories</th>
                    <th>Tags</th>
                    <th>Link</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($query->have_posts()) :
                    while ($query->have_posts()) : $query->the_post();
                        $meta_keywords = get_post_meta(get_the_ID(), 'meta_keywords', true);
                        $meta_desc = get_post_meta(get_the_ID(), 'meta_description', true);
                        $view_count = (int)get_post_meta(get_the_ID(), 'view_count', true);
                        $categories = get_the_category();
                        $tags = get_the_tags();

                        $cat_names = $categories ? implode(', ', wp_list_pluck($categories, 'name')) : '-';
                        $tag_names = $tags ? implode(', ', wp_list_pluck($tags, 'name')) : '-';

                        echo "<tr>
                            <td>" . esc_html(get_the_title()) . "</td>
                            <td>" . esc_html($meta_keywords) . "</td>
                            <td>" . esc_html($meta_desc) . "</td>
                            <td>" . intval($view_count) . "</td>
                            <td>" . esc_html(get_the_date()) . "</td>
                            <td>" . esc_html($cat_names) . "</td>
                            <td>" . esc_html($tag_names) . "</td>
                            <td><a href='" . esc_url(get_permalink()) . "' target='_blank'>View</a></td>
                        </tr>";
                    endwhile;
                else :
                    echo "<tr><td colspan='8'>No posts found.</td></tr>";
                endif;
                wp_reset_postdata();
                ?>
            </tbody>
        </table>

        <?php if ($total_pages > 1): ?>
            <div class="tablenav-pages" style="margin-top: 1rem;">
                <?php
                echo wp_kses_post(paginate_links([
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '«',
                    'next_text' => '»',
                    'total' => $total_pages,
                    'current' => $paged
                ]));
                ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}
