<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * =========================================================
 * CRON REGISTRATION
 * =========================================================
 */

add_filter('cron_schedules', function ($schedules) {
    $schedules['every_10_minutes'] = [
        'interval' => 600,
        'display'  => __('Every 10 Minutes', 'genwrite-ai-blogger'),
    ];

    return $schedules;
});

add_action('aiblogger_cron_event', 'aiblogger_process_sideload_posts');

/**
 * =========================================================
 * MAIN CRON PROCESSOR
 * =========================================================
 */

function aiblogger_process_sideload_posts()
{
    // Prevent overlapping cron runs
    if (get_transient('aiblogger_sideload_global_lock')) {
        return;
    }

    set_transient('aiblogger_sideload_global_lock', 1, 300);

    try {

        $posts = get_posts([
            'post_type'      => 'post',
            'post_status'    => 'any',
            'posts_per_page' => 5,
            'meta_query'     => [
                [
                    'key'   => '_aiblogger_needs_sideload',
                    'value' => '1',
                ],
            ],
        ]);

        foreach ($posts as $post) {

            $post_id = $post->ID;

            /**
             * Prevent same post from processing simultaneously
             */
            if (get_post_meta($post_id, '_aiblogger_processing', true)) {
                continue;
            }

            update_post_meta($post_id, '_aiblogger_processing', '1');

            try {

                $content = $post->post_content;

                if (empty($content)) {
                    update_post_meta($post_id, '_aiblogger_needs_sideload', '0');
                    continue;
                }

                $image_urls = aiblogger_extract_external_image_urls($content);

                if (empty($image_urls)) {
                    update_post_meta($post_id, '_aiblogger_needs_sideload', '0');
                    continue;
                }

                $new_content = $content;

                $errors = 0;

                foreach ($image_urls as $img_url) {

                    /**
                     * Reuse existing attachment if already imported
                     */
                    $existing_id = aiblogger_find_existing_attachment($img_url);

                    if ($existing_id) {

                        $uploaded_url = wp_get_attachment_url($existing_id);

                        if ($uploaded_url) {
                            $new_content = str_replace(
                                $img_url,
                                $uploaded_url,
                                $new_content
                            );
                        }

                        continue;
                    }

                    /**
                     * Download + sideload image
                     */
                    $media_id = aiblogger_sideload_image(
                        $img_url,
                        $post_id
                    );

                    if (is_wp_error($media_id)) {
                        $errors++;
                        continue;
                    }

                    /**
                     * Store source hash
                     */
                    update_post_meta(
                        $media_id,
                        '_aiblogger_source_hash',
                        md5($img_url)
                    );

                    /**
                     * Replace remote URL with local URL
                     */
                    $uploaded_url = wp_get_attachment_url($media_id);

                    if ($uploaded_url) {
                        $new_content = str_replace(
                            $img_url,
                            $uploaded_url,
                            $new_content
                        );
                    }
                }

                /**
                 * Save updated content
                 */
                if ($new_content !== $content) {

                    wp_update_post([
                        'ID'           => $post_id,
                        'post_content' => $new_content,
                    ]);
                }

                /**
                 * Success
                 */
                if ($errors === 0) {

                    update_post_meta(
                        $post_id,
                        '_aiblogger_needs_sideload',
                        '0'
                    );

                    delete_post_meta(
                        $post_id,
                        '_aiblogger_sideload_attempts'
                    );

                } else {

                    /**
                     * Retry handling
                     */
                    $attempts = (int) get_post_meta(
                        $post_id,
                        '_aiblogger_sideload_attempts',
                        true
                    );

                    $attempts++;

                    update_post_meta(
                        $post_id,
                        '_aiblogger_sideload_attempts',
                        $attempts
                    );

                    /**
                     * Stop retrying after 3 failures
                     */
                    if ($attempts >= 3) {

                        update_post_meta(
                            $post_id,
                            '_aiblogger_needs_sideload',
                            '0'
                        );
                    }
                }

            } catch (Exception $e) {

                error_log(
                    '[AIBLOGGER] Sideload error for post ' .
                    $post_id .
                    ': ' .
                    $e->getMessage()
                );

            } finally {

                delete_post_meta(
                    $post_id,
                    '_aiblogger_processing'
                );
            }
        }

    } finally {

        delete_transient('aiblogger_sideload_global_lock');
    }
}

/**
 * =========================================================
 * FIND EXISTING ATTACHMENT
 * =========================================================
 */

function aiblogger_find_existing_attachment($url)
{
    $hash = md5($url);

    $existing = get_posts([
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => 1,
        'meta_query'     => [
            [
                'key'   => '_aiblogger_source_hash',
                'value' => $hash,
            ],
        ],
    ]);

    if (empty($existing)) {
        return false;
    }

    return $existing[0]->ID;
}

/**
 * =========================================================
 * EXTRACT ONLY EXTERNAL IMAGES
 * =========================================================
 */

function aiblogger_extract_external_image_urls($content)
{
    preg_match_all(
        '/<img[^>]+src=["\']([^"\']+)["\']/i',
        $content,
        $matches
    );

    if (empty($matches[1])) {
        return [];
    }

    $site_host = wp_parse_url(
        home_url(),
        PHP_URL_HOST
    );

    $urls = [];

    foreach ($matches[1] as $url) {

        if (empty($url)) {
            continue;
        }

        /**
         * Skip already-local uploads
         */
        if (
            strpos($url, '/wp-content/uploads/') !== false
        ) {
            continue;
        }

        /**
         * Skip same-domain URLs
         */
        $host = wp_parse_url($url, PHP_URL_HOST);

        if (
            !empty($host) &&
            $host === $site_host
        ) {
            continue;
        }

        /**
         * Only allow http/https
         */
        if (
            strpos($url, 'http://') !== 0 &&
    strpos($url, 'https://') !== 0
        ) {
            continue;
        }

        $urls[] = $url;
    }

    return array_unique($urls);
}



