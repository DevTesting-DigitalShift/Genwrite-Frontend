=== AI Blogger Sync ===
Contributors: genwrite-team
Tags: ai, blogging, content, seo, automation
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 3.3.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Short Description: AI Blogger Sync allows you to receive AI-generated blog posts and upload them automatically with images, SEO tags, and real-time view tracking.

== Description ==
AI Blogger Sync is a powerful WordPress plugin that let's your wordpress website to connect our genwrite.co domain and let's you upload blogs generated using AI. It is a great tool for bloggers and content creators who want to save time and effort in writing articles. With AI Blogger Sync, you can easily generate high-quality content with just a few clicks at genwrite.co and post to your wordpress website with ease. This plugin includes schema markup additions, schedule image downloads in local media, table of contents addition etc to enhance your blogging experience and improve SEO, AEO and organic traffic.

== Installation ==
1. Upload `ai-blogger-sync` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure settings in **AI Blogger Sync → Settings**.

== Frequently Asked Questions ==
= Does it work with Gutenberg? =
Yes.

== Screenshots ==
1. Settings page screenshot.
2. Example post.

== Changelog ==
= 3.3.3 =
* Feature: SEO tags added
* Improvement: Media upload optimization

== Upgrade Notice ==
= 3.3.3 =
Added better SEO handling and bug fixes.
