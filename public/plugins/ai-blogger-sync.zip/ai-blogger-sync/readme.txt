=== GenWrite AI Blogger Sync ===
Contributors: genwrite-team
Tags: ai, blogging, content, seo, automation
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 3.3.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Short Description: Automatically sync AI-generated blog posts from GenWrite.co to your WordPress site, complete with images, SEO tags, and tracking.

== Description ==
GenWrite AI Blogger Sync is a WordPress plugin that connects your website to [GenWrite.co](https://genwrite.co), allowing you to automatically import and publish AI-generated blog posts.  

Once connected, you can generate articles on GenWrite.co and have them automatically uploaded to your WordPress site — including featured images, SEO metadata, and schema markup.  

**Key features include:**
- Automatic post publishing from GenWrite.co  
- Built-in SEO and schema markup for better visibility  
- Optional local image downloads to your media library  
- Table of contents support  
- Real-time post view tracking  

This plugin is designed to help bloggers, marketers, and content creators streamline their publishing workflow and keep their site updated effortlessly.

== Installation ==
1. Upload the `ai-blogger-sync` folder to the `/wp-content/plugins/` directory.  
2. Activate the plugin through the **Plugins** menu in WordPress.  
3. Go to **GenWrite AI Blogger Sync → Settings** and enter your GenWrite.co API key to connect your site.  
4. Once connected, your AI-generated posts will be synced automatically.

== Frequently Asked Questions ==
= Does it work with Gutenberg? =
Yes, GenWrite AI Blogger Sync works with both the Classic Editor and Gutenberg.

= Do I need a GenWrite.co account? =
Yes. You’ll need an active account on GenWrite.co to generate and sync AI content.

== Screenshots ==
1. Settings page with connection options  
2. Example of an AI-generated post published on WordPress  

== Changelog ==
= 3.3.3 =
* Added SEO tag support  
* Improved media upload handling  

== Upgrade Notice ==
= 3.3.3 =
Improved SEO handling and media upload optimization.
