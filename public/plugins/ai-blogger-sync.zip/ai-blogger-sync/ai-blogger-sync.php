<?php
/**
 * Plugin Name: GenWrite AI Blogger Sync
 * Description: Automatically sync AI-generated blog posts from GenWrite.co to your WordPress site.
 * Version: 3.3.5
 * Author: GenWrite Team
 * Author URI: https://genwrite.co
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * Tested up to: 6.8
 * Text Domain: genwrite-ai-blogger
 */

if (!defined('ABSPATH'))
    exit;

define('AIBLOGGER_SECRET_HASH_OPTION', 'aiblogger_secret_hash');

// 🔐 On activation, store the hashed secret
register_activation_hook(__FILE__, function () {
    if (!get_option(AIBLOGGER_SECRET_HASH_OPTION)) {
        $raw_secret = 'ai-blogger-uploader-genwrite';
        $hash = hash('sha256', $raw_secret);
        add_option(AIBLOGGER_SECRET_HASH_OPTION, $hash);
    }
});

add_action('init', function () {
    if (!get_option('aiblogger_cron_scheduled')) {
        if (!wp_next_scheduled('aiblogger_cron_event')) {
            wp_schedule_event(time(), 'every_10_minutes', 'aiblogger_cron_event');
        }
        update_option('aiblogger_cron_scheduled', true);
    }
	aiblogger_register_seo_meta();
});

// Enable post thumbnails support
add_action('after_setup_theme', function () {
    add_theme_support('post-thumbnails');
});

// ping handler
function aiblogger_ping($request)
{
    return new WP_REST_Response([
        'status' => 'success',
        'message' => 'AI Blogger plugin is active and authenticated.'
    ], 200);
}

// auth middleware
function aiblogger_is_authorized($request)
{
    $auth_header = $request->get_header('authorization');
    if (!$auth_header) {
        return new WP_Error('unauthorized', 'Missing Authorization header', ['status' => 401]);
    }

    $hashed = get_option(AIBLOGGER_SECRET_HASH_OPTION);
    $provided_hash = trim($auth_header);

    if (!hash_equals($hashed, $provided_hash)) {
        return new WP_Error('unauthorized', 'Invalid Authorization token', ['status' => 403]);
    }

    return true;
}

add_action('rest_api_init', function () {
    // blog post route
    register_rest_route('aiblogger/v1', '/post', [
        'methods' => 'POST',
        'callback' => 'aiblogger_handle_post',
        'permission_callback' => 'aiblogger_is_authorized',
    ]);
    // get blog info route
    register_rest_route('aiblogger/v1', '/post/(?P<id>\\d+)', [
        'methods' => 'GET',
        'callback' => 'aiblogger_get_post_info',
        'permission_callback' => 'aiblogger_is_authorized',
    ]);
    // get blog metadata (title, desc, views ) route
    register_rest_route('aiblogger/v1', '/meta/(?P<id>\\d+)', [
        'methods' => 'GET',
        'callback' => 'aiblogger_get_post_meta',
        'permission_callback' => 'aiblogger_is_authorized',
    ]);
    //ping route
    register_rest_route('aiblogger/v1', '/ping', [
        'methods' => 'GET',
        'callback' => 'aiblogger_ping',
        'permission_callback' => 'aiblogger_is_authorized'
    ]);
});

function aiblogger_handle_post($request)
{
    $post_id = $request->get_param('id');
    $title = sanitize_text_field($request->get_param('title'));
    $content = $request->get_param('content');
    $meta_title = $request->get_param('meta_title') ?: $title;
    $meta_description = sanitize_text_field($request->get_param('meta_description')) ?: mb_substr(trim(wp_strip_all_tags($content)), 0, 160);
    $meta_keywords = sanitize_text_field($request->get_param('meta_keywords'));
    $featured_image_url = esc_url_raw($request->get_param('featured_image_url'));
    $featured_image_alt = sanitize_text_field($request->get_param('featured_image_alt') ?? '');
    $category = sanitize_text_field($request->get_param('category'));
    $tags = $request->get_param('tags');
	$summary = $request->get_param('custom_summary');
	$schema = $request->get_param('schema_markup');
	
	// 🆕 Capture and sanitize the slug
    $slug = sanitize_title($request->get_param('slug'));
    

    if (!$post_id || !get_post_status($post_id)) {
        // Create new post
        $post_id = aiblogger_create_post($title, $content, $slug);
        if (is_wp_error($post_id)) {
            return new WP_REST_Response(['error' => 'Post creation failed'], 500);
        }
    }
		else {
    // ✅ Update existing post
    $update_result = wp_update_post([
        'ID'           => $post_id,
        'post_title'   => $title,
        'post_content' => $content,
    ], true);

    if (is_wp_error($update_result)) {
        return new WP_REST_Response(['error' => 'Post update failed'], 500);
    }
	}
	$image_urls = aiblogger_extract_image_urls($content);
    if (!empty($image_urls)) {
    update_post_meta($post_id, '_aiblogger_needs_sideload', true);
    delete_post_meta($post_id, '_aiblogger_sideload_attempts'); // reset retries
}


    update_post_meta($post_id, 'meta_title', $meta_title);
	update_post_meta($post_id, 'canonical_url', get_permalink($post_id));
    if ($meta_description)
        update_post_meta($post_id, 'meta_description', $meta_description);
    if ($meta_keywords)
        update_post_meta($post_id, 'meta_keywords', $meta_keywords);
	if($summary)
		update_post_meta($post_id, 'custom_summary', $summary);
	if($schema)
		update_post_meta($post_id, 'schema_markup', $schema);
    // Ensure view count is always initialized
    if (!get_post_meta($post_id, 'view_count', true)) {
        update_post_meta($post_id, 'view_count', 0);
    }


    // 📸 Set thumbnail if provided
    if (!empty($featured_image_url)) {
        $media_id = aiblogger_sideload_image($featured_image_url, $post_id);

        if (!is_wp_error($media_id)) {
            set_post_thumbnail($post_id, $media_id);

            // ✅ Option 4: Set alt text for featured image
            if (!empty($featured_image_alt)) {
                update_post_meta($media_id, '_wp_attachment_image_alt', sanitize_text_field($featured_image_alt));
            }
        }
    }

    // 🏷 Assign tags
    if ($tags && is_array($tags)) {
        wp_set_post_tags($post_id, $tags);
    }

    if ($category) {
        // Get the category by name or slug, or create it if not exists
        $cat = get_term_by('name', $category, 'category') ?: get_term_by('slug', sanitize_title($category), 'category');

        if (!$cat) {
            // Create the category
            $cat_result = wp_insert_term($category, 'category');
            if (!is_wp_error($cat_result)) {
                $cat_id = $cat_result['term_id'];
            }
        } else {
            $cat_id = $cat->term_id;
        }

        if (isset($cat_id)) {
            wp_set_post_categories($post_id, [$cat_id]);
        }
    }

    return new WP_REST_Response(['success' => true, 'post_id' => $post_id, 'link' => get_permalink($post_id)], 200);
}

// extract image urls from html
function aiblogger_extract_image_urls($content)
{
    preg_match_all('/<img[^>]+src="([^"]+)"[^>]*>/i', $content, $matches);
    return $matches[1];
}

// create post
// create post
function aiblogger_create_post($title, $content, $slug = '')
{
    $post_data = [
        'post_title'   => $title,
        'post_content' => $content,
        'post_status'  => 'publish',
        'post_author'  => 1,
    ];

    // ✅ Only set post_name (slug) if provided
    if (!empty($slug)) {
        $post_data['post_name'] = $slug;
    }

    return wp_insert_post($post_data);
}

function aiblogger_sideload_image($img_url, $post_id)
{
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $tmp = download_url($img_url);
    if (is_wp_error($tmp))
        return $tmp;

    $file_info = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($file_info, $tmp);
    finfo_close($file_info);

    $ext = pathinfo(wp_parse_url($img_url, PHP_URL_PATH), PATHINFO_EXTENSION);
    if (!$ext) {
        switch ($mime_type) {
            case 'image/jpeg':
                $ext = 'jpg';
                break;
            case 'image/png':
                $ext = 'png';
                break;
            case 'image/gif':
                $ext = 'gif';
                break;
            default:
                $ext = 'webp';
                break;
        }
    }

    $file_array = [
        'name' => basename($img_url) . '.' . $ext,
        'tmp_name' => $tmp,
    ];

    return media_handle_sideload($file_array, $post_id);
}


// handle image upload
function aiblogger_handle_images($image_urls, $post_id, $content)
{
    foreach ($image_urls as $index => $img_url) {
        $media_id = aiblogger_sideload_image($img_url, $post_id);

        if (!is_wp_error($media_id)) {
            $uploaded_url = wp_get_attachment_url($media_id);
            $content = preg_replace('/' . preg_quote($img_url, '/') . '/', $uploaded_url, $content, 1);
        }
    }

    return $content;
}

// View tracking (refresh only) using post-hook
add_action('template_redirect', function () {
    if (is_single()) {
        global $post;

        // Make sure the global post object is populated
        if (!$post || !$post->ID || $post->post_status != "publish")
            return;

        // Track the real user view
        aiblogger_count_real_user_view($post->ID);
    }
});

// 🧠 Track views: only real users but currently using refreshes as user
function aiblogger_count_real_user_view($post_id)
{
    // Update post_meta view count
    $views = (int) get_post_meta($post_id, 'view_count', true);
    update_post_meta($post_id, 'view_count', $views + 1);
}

// REST API - Get post info
function aiblogger_get_post_info($data)
{
    $post_id = $data['id'];
    $post = get_post($post_id);
    if (!$post)
        return new WP_REST_Response(['error' => 'Post not found'], 404);
    return [
        'ID' => $post->ID,
        'title' => get_the_title($post),
        'link' => get_permalink($post),
        'status' => $post->post_status,
        'author' => get_the_author_meta('display_name', $post->post_author),
        'date' => $post->post_date
    ];
}

// REST API - Get meta
function aiblogger_get_post_meta($data)
{
    $post_id = $data['id'];
    return [
        'meta_title' => get_post_meta($post_id, 'meta_title', true) ?: '',
        'meta_description' => get_post_meta($post_id, 'meta_description', true) ?: '',
        'meta_keywords' => get_post_meta($post_id, 'meta_keywords', true) ?: '',
        'view_count' => (int) get_post_meta($post_id, 'view_count', true)
    ];
}

// 🟢 Register meta fields
function aiblogger_register_seo_meta() {
    $meta_fields = [
        'meta_title'       => 'string',
        'meta_description' => 'string',
        'meta_keywords'    => 'string',
        'custom_summary'   => 'string',
        'canonical_url'    => 'string',
        'schema_markup'    => 'string', // JSON string
    ];

    foreach ($meta_fields as $key => $type) {
        register_post_meta('post', $key, [
            'show_in_rest'  => true,
            'single'        => true,
            'type'          => $type,
            'auth_callback' => function() {
                return current_user_can('edit_posts');
            },
        ]);
    }
}

// 🧠 Inject meta tags (SEO + social)
add_action('wp_head', function () {
    if (!is_single())
        return;

    global $post;
	
	$title     = get_post_meta($post->ID, 'meta_title', true) ?: get_the_title($post);
    $desc      = get_post_meta($post->ID, 'meta_description', true) ?: get_the_excerpt($post);
    $keywords  = get_post_meta($post->ID, 'meta_keywords', true);
    $summary   = get_post_meta($post->ID, 'custom_summary', true);
    $thumb_url = get_the_post_thumbnail_url($post, 'full');
    $canonical = get_post_meta($post->ID, 'canonical_url', true) ?: get_permalink($post);
    $schema    = get_post_meta($post->ID, 'schema_markup', true); // JSON string

    echo "<meta name='description' content='" . esc_attr($desc) . "' />\n";
    if ($keywords)
        echo "<meta name='keywords' content='" . esc_attr($keywords) . "' />\n";

    echo "<meta property='og:title' content='" . esc_attr($title) . "' />\n";
    echo "<meta property='og:description' content='" . esc_attr($desc) . "' />\n";
    echo "<meta property='og:type' content='article' />\n";

    echo "<meta name='twitter:card' content='summary_large_image' />\n";
    echo "<meta name='twitter:title' content='" . esc_attr($title) . "' />\n";
    echo "<meta name='twitter:description' content='" . esc_attr($desc) . "' />\n";
    if ($thumb_url) {
        echo "<meta property='og:image' content='" . esc_url($thumb_url) . "' />\n";
        echo "<meta name='twitter:image' content='" . esc_url($thumb_url) . "' />\n";
    }
	
	 if ($summary) {
        echo "<meta name='summary' content='" . esc_attr($summary) . "' />\n";
    }
	
	 // ✅ Canonical
    if ($canonical) {
        echo "<link rel='canonical' href='" . esc_url($canonical) . "' />\n";
    }

    // ✅ Schema Markup
    if ($schema) {
        $decoded = json_decode($schema, true);

        if (json_last_error() === JSON_ERROR_NONE) {
            // Force array to support multiple schemas
            $schemas = isset($decoded[0]) ? $decoded : [$decoded];

            foreach ($schemas as $sch) {
                if (is_array($sch)) {
                    echo "<script type='application/ld+json'>" .
                         wp_json_encode($sch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) .
                         "</script>\n";
                }
            }
        }
	}
}, 5);

add_filter('wp_kses_allowed_html', function ($tags, $context) {
    if ($context === 'post') {
        $tags['iframe'] = array(
            'src'             => true,
            'height'          => true,
            'width'           => true,
            'frameborder'     => true,
            'allowfullscreen' => true,
            'style'           => true,
            'title'           => true,
            'allow'           => true, // Essential for YT features
        );
        $tags['div'] = array(
            'style' => true,
            'class' => true,
        );
    }
    return $tags;
}, 10, 2);


// file imports
require_once plugin_dir_path(__FILE__) . 'includes/dashboard.php';
require_once plugin_dir_path(__FILE__) . 'cron/aiblogger_cron.php';

