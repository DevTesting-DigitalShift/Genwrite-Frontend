<?php
add_action('admin_menu', function () {
    add_menu_page(
        'AI Blogger Sync',
        'AI Blogger',
        'manage_options',
        'ai-blogger-sync',
        'aiblogger_admin_dashboard',
		'dashicons-cloud',
        26
    );
});

function aiblogger_admin_dashboard() {
    $posts = get_posts([
                    'post_type' => 'post',
                    'posts_per_page' => 50,
                    'orderby' => 'date',
                    'order' => 'DESC',
                    'meta_query' => [
                        [
                            'key' => 'meta_title',
                            'compare' => 'EXISTS'
                        ]
                    ]
                ]);
    ?>
    <div class="wrap ai-blogger-dashboard">
        <h1>
            <img src="<?php echo plugin_dir_url(__FILE__) . 'assets/logo.png'; ?>" alt="Logo" style="height:32px;vertical-align:middle;margin-right:10px;">
            AI Blogger Sync Connected
        </h1>
        <p style="font-size:1rem;" >Plugin is connected with <a href="https://app.genwrite.co" target="_blank">app.genwrite.co</a>.</p>

        <h2>Synced Blog Posts</h2>
        <p>Total Synced Posts: <strong><?php echo count($posts); ?></strong></p>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Keywords</th>
                    <th>Meta Desc</th>
                    <th>Views</th>
                    <th>Date</th>
                    <th>Link</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($posts as $post) {
                    $meta_keywords = get_post_meta($post->ID, 'meta_keywords', true);
                    $meta_desc = get_post_meta($post->ID, 'meta_description', true);
                    $view_count = (int)get_post_meta($post->ID, 'view_count', true);
                    echo "<tr>
                        <td>{$post->post_title}</td>
                        <td>{$meta_keywords}</td>
                        <td>{$meta_desc}</td>
                        <td>{$view_count}</td>
                        <td>{$post->post_date}</td>
                        <td><a href='" . get_permalink($post) . "' target='_blank'>View</a></td>
                    </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__) . 'assets/style.css'; ?>">
    <?php
}
